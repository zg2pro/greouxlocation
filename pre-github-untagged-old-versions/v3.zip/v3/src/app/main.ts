import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {AppModule} from './ts/app.module';


platformBrowserDynamic().bootstrapModule(AppModule);

