export class Fare {
    category: string;
    value: number;
}
