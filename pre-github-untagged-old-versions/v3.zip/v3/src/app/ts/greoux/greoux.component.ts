import {Component} from '@angular/core';

@Component({
    selector: 'greoux-component',
    templateUrl: 'templates/greoux.component.html',
    styleUrls: ['resources/styles/greoux.component.css']
})
export class GreouxComponent {


}
