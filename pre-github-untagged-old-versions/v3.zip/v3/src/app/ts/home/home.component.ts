import {Component} from '@angular/core';

@Component({
    selector: 'home-component',
    templateUrl: 'templates/home.component.html',
    styleUrls: ['resources/styles/home.component.css']
})
export class HomeComponent {

}
