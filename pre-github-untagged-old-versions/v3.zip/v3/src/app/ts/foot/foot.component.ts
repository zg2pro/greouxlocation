import {Component} from '@angular/core';


@Component({
    //moduleId: module.id,
    selector: 'foot',
    templateUrl: 'templates/foot.component.html',
    styleUrls: ['resources/styles/foot.component.css']
})
export class FootComponent {

    

}