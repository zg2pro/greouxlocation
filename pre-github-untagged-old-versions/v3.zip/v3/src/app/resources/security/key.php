<?php


define('XLS_DOC', '1eea9FY1OmrBq7wiMGIDaRzSGfcUnEIRZoEFvIdoi_iU');
define('XLS_KEY', '4/6l9Lul-F-G2Vwly9iXydoaqb7triN6CLElYSZpLoF1c');
define('XLS_API_KEY', 'AIzaSyBUUFdgAx3qFAD-CGYQI9Myd-SD2TwgX1c');
define('BASE_PWD', 'uqbdzhp');

?>