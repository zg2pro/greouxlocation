<?php

define(BASE_RESOURCES_PATH, 'resources/');
define(BASE_VENDOR_PATH, 'vendor/');

?>
